package com.example.food;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.ImageView;
import android.widget.TextView;

public class pizzatimer extends AppCompatActivity {

    // CHANGE THIS TO DECIDE HOW LONG TO COOK SOMETHING
    private long minutesCook = 0;
    private long secondsCook = 10;
    private int tempCook = 425;


    private String temperatureString = "" + tempCook + " Degrees";
    private long timeleft = ((minutesCook * 60) + secondsCook) * 1000;
    private CountDownTimer countDownTimer ;
    TextView timerText;
    TextView tempText;
    public int minutes;
    public int seconds;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);

        timerText = findViewById(R.id.textView2);
        tempText = findViewById(R.id.textView3);
        tempText.setText(temperatureString);
        startTimer();


    }


    public void startTimer()
    {
        countDownTimer = new CountDownTimer(timeleft, 1000)
        {

            @Override
            public void onTick(long millisUntilFinished)
            {
                timeleft = millisUntilFinished;
                updateTimerText();

            }

            @Override
            public void onFinish() {

            }
        }.start();

    }

    public void updateTimerText()
    {
        minutes = (int) timeleft / 60000;
        seconds = ((int) timeleft % 60000) / 1000;

        String timeLeftText;


        if (minutes > 0)
        {
            timeLeftText = "" + minutes + ":";
            if (seconds > 9)
            {
                timeLeftText += "" + seconds;
            }
            else
            {
                // add 0 before the seconds value
                timeLeftText += "0" + seconds;
            }
        }
        else
        {
            // dont need to do the minutes and the :

            if (seconds > 9)
            {
                timeLeftText = "" + seconds;
            }
            else
            {
                // add 0 before the seconds value
                if (seconds > 1)
                {
                    timeLeftText = "0" + seconds;
                }
                else
                {
                    timeLeftText = "DONE";
                    Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                    Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
                    r.play();
                }
            }
        }

        timerText.setText(timeLeftText);
    }


}
