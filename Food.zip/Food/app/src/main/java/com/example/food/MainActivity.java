package com.example.food;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    TextView myTextBox;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView myImageView = findViewById(R.id.myImageView);
        myImageView.setImageResource(R.mipmap.pizzaround_round);

        ImageView chickenImage = findViewById(R.id.chickenImageView);
        chickenImage.setImageResource(R.mipmap.chickenround_round);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////

    public void pizzaFunction(View view)
    {
        // Change scene to a timer  and maybe display temperature too
        Intent myIntent = new Intent(MainActivity.this, pizzatimer.class);
        startActivity(myIntent);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////

    public void chickenFunction(View view)
    {
        // Change scene to a timer  and maybe display temperature too
        Intent myIntent = new Intent(MainActivity.this, chickentimer.class);
        startActivity(myIntent);
    }
}
