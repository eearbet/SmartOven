package com.example.food;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;

public class chickentimer extends AppCompatActivity {

    TextView timerText;
    TextView tempText;
    private int tempCook = 80;
    private CountUpTimer timer ;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);

        timerText = findViewById(R.id.textView2);
        tempText = findViewById(R.id.textView3);
        startTimer();
    }

    public void startTimer()
    {
        timer = (CountUpTimer) new CountUpTimer(30000)
        {
            public void onTick(int second)
            {
                updateTimerAndTempText(second);

            }
        }.start();
    }



    public abstract class CountUpTimer extends CountDownTimer {
        private static final long INTERVAL_MS = 1000;
        private final long duration;

        protected CountUpTimer(long durationMs) {
            super(durationMs, INTERVAL_MS);
            this.duration = durationMs;
        }

        public abstract void onTick(int second);

        @Override
        public void onTick(long msUntilFinished) {
            int second = (int) ((duration - msUntilFinished) / 1000);
            onTick(second);
        }

        @Override
        public void onFinish() {
            onTick(duration / 1000);
        }
    }


    public void updateTimerAndTempText(int secondsTotal)
    {
        int minutes = (int) secondsTotal / 60;
        int seconds = (int) secondsTotal % 60;

        String timeTotalText;

        if (minutes > 0)
        {
            timeTotalText = "" + minutes + ":";
            if (seconds > 9)
            {
                timeTotalText += "" + seconds;
            }
            else
            {
                // add 0 before the seconds value
                timeTotalText += "0" + seconds;
            }
        }
        else
        {
            // dont need to do the minutes and the :

            if (seconds > 9)
            {
                timeTotalText = "" + seconds;
            }
            else
            {
                timeTotalText = "0" + seconds;
            }
        }

        int temp = secondsTotal * 5;

        if (temp > tempCook)
        {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
            r.play();
            timer.cancel();
        }
        else
        {
            tempText.setText(String.valueOf(temp));
            timerText.setText(String.valueOf(timeTotalText));
        }


    }
}
